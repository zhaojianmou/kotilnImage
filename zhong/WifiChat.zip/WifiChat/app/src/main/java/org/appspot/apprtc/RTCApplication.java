package org.appspot.apprtc;

import hillfly.wifichat.common.BaseApplication;

/**
 * Created by cxm on 7/28/16.
 */
public class RTCApplication extends BaseApplication {
    private static RTCComponent component;

    public static RTCComponent getComponent() { return component; }

    public void onCreate() {
        super.onCreate();

        component = DaggerRTCComponent.builder().
                build();

        // TODO online service
//        OnlineService.start();
    }
}
