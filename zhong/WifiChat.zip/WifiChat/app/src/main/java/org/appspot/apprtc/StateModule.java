package org.appspot.apprtc;

import javax.inject.Singleton;

import dagger.Module;
import dagger.Provides;

/**
 * Created by cxm on 2/28/17.
 */
@Module
public class StateModule {
    @Provides
    @Singleton
    StateProvider provideStateProvider() {
        StateProvider stateProvider = new StateProvider();
        XLog.d("Create stateProvider at " + stateProvider);
        return stateProvider;
    }
}
