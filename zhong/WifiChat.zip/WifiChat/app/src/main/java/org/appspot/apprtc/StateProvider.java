package org.appspot.apprtc;

import org.appspot.apprtc.data.CallSignal;
import org.appspot.apprtc.data.RoomConnectionParameters;

import de.greenrobot.event.EventBus;

/**
 * Created by cxm on 2/28/17.
 */
public class StateProvider {
    public enum State {
        STATE_SIGNOUT,
        STATE_SIGNOUTING,
        STATE_SIGNING,
        STATE_SIGNIN,
        STATE_CONNECTING,
        STATE_CONNECT,
        STATE_DISCONNECTING
    };

    private State state = State.STATE_SIGNOUT;

    private AppRTCClient appRtcClient = null;
    private RoomConnectionParameters parameters;

    public State getState() { return state; }

    public void setState(State state) {
        if (!this.state.equals(state)) {
            XLog.i("Connection state change from: " + this.state + " to: " + state);
            this.state = state;
            EventBus.getDefault().post(this.state);
        }
    }

    public boolean isLogin() {
        return (!State.STATE_SIGNOUT.equals(state)) &&
                (!State.STATE_SIGNING.equals(state)) &&
                (!State.STATE_SIGNOUTING.equals(state));
    }

    public AppRTCClient getAppRtcClient() {
        return appRtcClient;
    }

    public StateProvider() {
        EventBus.getDefault().register(this);
    }

    public int login() {

        setState(State.STATE_SIGNIN);
        return 0;
    }

    public void logout() {
        setState(State.STATE_SIGNOUT);
    }

    public AppRTCClient call(RoomConnectionParameters parameters) {
        if (null != appRtcClient || !State.STATE_SIGNIN.equals(state)) {
            XLog.e("Invalid state: " + state + " client: " + appRtcClient);
            return null;
        }

        appRtcClient = new XmppRTCClient();
        appRtcClient.connectToRoom(parameters);
        this.parameters = parameters;
        setState(State.STATE_CONNECTING);

        return appRtcClient;
    }

    public AppRTCClient accept() {
        if (null == appRtcClient || !State.STATE_CONNECTING.equals(state)) {
            XLog.e("Invalid state: " + state);
            return null;
        }

        appRtcClient.accept();
        return appRtcClient;
    }

    public void hangup() {
        if ((!State.STATE_CONNECT.equals(state)) &&
                (!State.STATE_CONNECTING.equals(state)) &&
                (!State.STATE_DISCONNECTING.equals(state))) {
            XLog.e("Invalid state: " + state);
            return;
        }

        setState(State.STATE_DISCONNECTING);

        // TODO async stuff
        appRtcClient.disconnectFromRoom();
        appRtcClient = null;
        setState(State.STATE_SIGNIN);
    }

    @SuppressWarnings("unused")
    public void onEvent(CallSignal signal) {
        // TODO verify signal
        if (null == appRtcClient || !State.STATE_CONNECTING.equals(state)) {
            XLog.e("Invalid state: " + state);
            return;
        }

        XLog.d("Receive signal session id: " + signal.getCallSessionID());
        appRtcClient.getParameters().updateParameterFromCallSignal(signal);
    }
}
