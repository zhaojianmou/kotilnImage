package org.appspot.apprtc.data;

/**
 * Created by cxm on 7/30/16.
 */
public class Signal {
    public static final String TYPE_CALL = "call";
    public static final String TYPE_ACCEPT = "accept";
    public static final String TYPE_DISCONNECT = "hangup";
    public static final String TYPE_ICE_ADD = "iceAdd";
    public static final String TYPE_ICE_REMOVE = "iceRemove";
    public static final String TYPE_SDP = "sdp";
    public static final String TYPE_PING = "callPing";

    public static final int ERROR_CODE_NO_MONEY = 1;
    public static final int ERROR_CODE_NOT_AVAILABLE = 2;

    private String callFrom;
    private String callTo;
    private String type;
    private String callSessionID;
    private int code;
    public String message;

    public Signal(String type) {
        this.type = type;
    }

    public String getCallFrom() { return callFrom; }
    public void setCallFrom(String callFrom) { this.callFrom = callFrom; }

    public String getCallTo() { return callTo; }
    public void setCallTo(String callTo) { this.callTo = callTo; }

    public String getType() { return type; }
    public String getCallSessionID() { return callSessionID; }
    public void setCallSessionID(String sessionID) { this.callSessionID = sessionID; }

    public int getCode() { return code; }
    public String getMessage() { return message; }
}
