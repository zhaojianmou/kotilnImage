package org.appspot.apprtc;

import javax.inject.Singleton;

import dagger.Module;
import dagger.Provides;

/**
 * Created by cxm on 7/29/16.
 */
@Module
public class ChannelModule {
    @Provides
    @Singleton
    ChannelsProvider provideChannelProvider() {
        ChannelsProvider channelProvider = new ChannelsProvider();
        XLog.d("Create ChannelsProvider at " + channelProvider);
        return channelProvider;
    }
}
