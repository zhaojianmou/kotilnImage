package org.appspot.apprtc;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by cxm on 7/29/16.
 */
public class Channel {
    private List<ChannelListner> listners = new ArrayList<>();

    public Channel() {
    }

    public void addListener(ChannelListner listner) {
        if (null == listner)
            throw new IllegalArgumentException("listener");

        if (!listners.contains(listner))
            listners.add(listner);
    }

    public void removeListener(ChannelListner listner) {
        if (listners.contains(listner))
            listners.remove(listner);
    }

    public void fireMessageNotify(String user, Object message) {
        for (ChannelListner listner : listners)
            listner.onChannelMessage(user, message);
    }

    public int init() {
        return 0;
    }

    public void deinit() {
    }

    public void send() {

    }

    public interface ChannelListner {
        void onChannelMessage(String user, Object message);
    }
}
