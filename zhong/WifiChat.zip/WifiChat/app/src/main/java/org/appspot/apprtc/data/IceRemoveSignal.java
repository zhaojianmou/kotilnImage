package org.appspot.apprtc.data;

import org.webrtc.IceCandidate;

/**
 * Created by cxm on 8/6/16.
 */
public class IceRemoveSignal extends Signal {
    private IceCandidate[] iceCandidates;

    public IceRemoveSignal() {
        super(TYPE_ICE_REMOVE);
    }

    public void setIceCandidates(IceCandidate[] candidates) { iceCandidates = candidates; }
    public IceCandidate[] getIceCandidates() { return iceCandidates; }
}
