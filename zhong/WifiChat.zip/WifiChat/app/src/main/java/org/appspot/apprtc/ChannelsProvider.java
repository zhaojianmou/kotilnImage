package org.appspot.apprtc;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by cxm on 7/29/16.
 */
public class ChannelsProvider {
    List<Channel> channelList = new ArrayList<>();
    private boolean isInit = false;

    public ChannelsProvider() {

    }

    public synchronized int init() {
        if (isInit) {
            XLog.e("already init");
            return -1;
        }

        channelList.clear();
        channelList.add(new IQSignalChannel());

        for (Channel channel : channelList)
            channel.init();
        isInit = true;

        return  0;
    }

    public synchronized void deinit() {
        if (isInit) {
            for (Channel channel : channelList)
                channel.deinit();
        }
        channelList.clear();
        isInit = false;
    }

    public synchronized <T extends Channel> T getChannel(Class<T> type) {
        for (Channel channel : channelList)
            if (channel.getClass().equals(type))
                return type.cast(channel);

        return null;
    }
}
