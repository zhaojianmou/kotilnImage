package org.appspot.apprtc.data;

import org.webrtc.IceCandidate;

/**
 * Created by cxm on 8/6/16.
 */
public class IceAddSignal extends Signal {
    private IceCandidate data;

    public IceAddSignal() {
        super(TYPE_ICE_ADD);
    }

    public void setData(IceCandidate candidate) { data = candidate; }
    public IceCandidate getData() { return data; }
}
