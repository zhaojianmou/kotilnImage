package org.appspot.apprtc;

import com.google.gson.Gson;

import org.appspot.apprtc.data.Signal;

import hillfly.wifichat.common.socket.udp.UDPMessageListener;
import hillfly.wifichat.consts.IPMSGConst;
import hillfly.wifichat.model.Message;
import hillfly.wifichat.util.DateUtils;
import hillfly.wifichat.util.SessionUtils;

/**
 * Created by cxm on 7/30/16.
 */
public class IQSignalChannel extends Channel {
    private static final String QUERY_NAME = "query";
    private static final String QUERY_NAMESPACE = "https://ppface.com/callSession";

    private String remoteIp;

    public void setRemoteIp(String remoteIp) { this.remoteIp = remoteIp; }

    public IQSignalChannel() {
        super();
    }

    public int init() {
        XLog.i("init iq signal channel");

        return 0;
    }

    public void deinit() {
        XLog.i("deinit signal channel");
    }

    public void sendSignal(Signal signal) {
        Gson gson = new Gson();
        Message msg = new Message(SessionUtils.getIMEI(), DateUtils.getNowtime(),
                gson.toJson(signal), Message.CONTENT_TYPE.CALL);

        XLog.i("Send signal: " + gson.toJson(signal));

        UDPMessageListener.sendUDPdata(IPMSGConst.IPMSG_SENDMSG, remoteIp, msg);
    }
}
