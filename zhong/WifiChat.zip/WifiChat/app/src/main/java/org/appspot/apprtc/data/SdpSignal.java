package org.appspot.apprtc.data;

import org.webrtc.SessionDescription;

/**
 * Created by cxm on 8/5/16.
 */
public class SdpSignal extends Signal {
    private SessionDescription data;

    public SdpSignal() {
        super(TYPE_SDP);
    }

    public SessionDescription getData() { return data; }
    public void setData(SessionDescription data) { this.data = data; }
}
