package org.appspot.apprtc;


import javax.inject.Singleton;

import dagger.Component;
import hillfly.wifichat.activity.AcceptFragment;
import hillfly.wifichat.activity.CallActivity;
import hillfly.wifichat.activity.CallFragment;
import hillfly.wifichat.activity.ChatActivity;
import hillfly.wifichat.activity.WelcomeActivity;
import hillfly.wifichat.common.socket.udp.UDPMessageListener;

/**
 * Created by cxm on 7/26/16.
 */
@Component(
    modules =  {
        ChannelModule.class,
        StateModule.class
    }
)
@Singleton
public interface RTCComponent {
    void inject(XmppRTCClient client);
    void inject(CallActivity activity);
    void inject(AcceptFragment fragment);
    void inject(CallFragment fragment);
    void inject(WelcomeActivity activity);
    void inject(ChatActivity activity);
    void inject(UDPMessageListener listener);
}
