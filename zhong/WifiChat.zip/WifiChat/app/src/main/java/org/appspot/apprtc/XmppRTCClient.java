package org.appspot.apprtc;

import org.appspot.apprtc.data.*;
import org.webrtc.IceCandidate;
import org.webrtc.SessionDescription;

import javax.inject.Inject;

import de.greenrobot.event.EventBus;

/**
 * Created by cxm on 7/30/16.
 */
public class XmppRTCClient implements AppRTCClient {
    @Inject
    ChannelsProvider channelsProvider;

    private RoomConnectionParameters connectionParameters;

    public XmppRTCClient() {
        RTCApplication.getComponent().inject(this);
    }

    @Override
    public void connectToRoom(RoomConnectionParameters connectionParameters) {
        this.connectionParameters = connectionParameters;
        if (connectionParameters.initiator)
            channelsProvider.getChannel(IQSignalChannel.class).sendSignal(
                setupSignal(new CallSignal()));
    }

    @Override
    public void accept() {
        channelsProvider.getChannel(IQSignalChannel.class).sendSignal(
                setupSignal(new AcceptSignal()));
    }

    @Override
    public void sendOfferSdp(SessionDescription sdp) {
        SdpSignal sdpSignal = new SdpSignal();
        sdpSignal.setData(sdp);
        if (connectionParameters.loopback) {
            // In loopback mode rename this offer to answer and route it back.
            SessionDescription sdpAnswer = new SessionDescription(
                    SessionDescription.Type.fromCanonicalForm("answer"),
                    sdp.description);
            sdpSignal.setData(sdpAnswer);
            EventBus.getDefault().post(sdpSignal);
            return;
        }
        setupSignal(sdpSignal);

        channelsProvider.getChannel(IQSignalChannel.class).sendSignal(sdpSignal);
    }

    @Override
    public void sendAnswerSdp(SessionDescription sdp) {
        throw new RuntimeException("not implementation");
    }

    @Override
    public void sendLocalIceCandidate(IceCandidate candidate) {
        IceAddSignal signal = new IceAddSignal();
        signal.setData(candidate);
        setupSignal(signal);
        if (connectionParameters.loopback) {
            EventBus.getDefault().post(signal);
            return;
        }

        channelsProvider.getChannel(IQSignalChannel.class).sendSignal(signal);
    }

    @Override
    public void sendLocalIceCandidateRemovals(IceCandidate[] candidates) {
        IceRemoveSignal signal = new IceRemoveSignal();
        signal.setIceCandidates(candidates);
        setupSignal(signal);

        channelsProvider.getChannel(IQSignalChannel.class).sendSignal(signal);
    }

    @Override
    public void sendPing() {
        channelsProvider.getChannel(IQSignalChannel.class).sendSignal(
                setupSignal(new PingSignal()));
    }

    @Override
    public void disconnectFromRoom() {
        channelsProvider.getChannel(IQSignalChannel.class).sendSignal(
                setupSignal(new DisconnectSignal()));
    }

    private Signal setupSignal(Signal signal) {
        return signal;
    }

    @Override
    public RoomConnectionParameters getParameters() {
        return connectionParameters;
    }
}
