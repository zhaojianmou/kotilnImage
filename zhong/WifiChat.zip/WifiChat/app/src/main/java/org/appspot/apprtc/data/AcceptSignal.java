package org.appspot.apprtc.data;

/**
 * Created by xiemchen on 3/5/17.
 */

public class AcceptSignal extends Signal {
    public AcceptSignal() {
        super(TYPE_ACCEPT);
    }
}
