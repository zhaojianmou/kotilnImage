package org.appspot.apprtc.data;

/**
 * Created by cxm on 7/31/16.
 */
public class DisconnectSignal extends Signal {
    public DisconnectSignal() {
        super(TYPE_DISCONNECT);
    }
}
