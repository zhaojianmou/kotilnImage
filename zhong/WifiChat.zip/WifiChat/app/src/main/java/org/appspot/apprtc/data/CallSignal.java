package org.appspot.apprtc.data;

/**
 * Created by cxm on 7/31/16.
 */
public class CallSignal extends Signal {
    private String turnServerAddress;
    private String turnUserName;
    private String turnPassword;

    public String getTurnServerAddress() { return turnServerAddress; }
    public String getTurnUserName() { return turnUserName; }
    public String getTurnPassword() { return turnPassword; }

    public CallSignal() {
        super(TYPE_CALL);
    }
}
