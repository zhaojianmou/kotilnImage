package hillfly.wifichat.activity;

import android.media.MediaPlayer;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;


import org.appspot.apprtc.RTCApplication;
import org.appspot.apprtc.StateProvider;
import org.appspot.apprtc.XLog;
import org.appspot.apprtc.data.AcceptSignal;
import org.appspot.apprtc.data.DisconnectSignal;
import org.appspot.apprtc.data.RoomConnectionParameters;

import javax.inject.Inject;

import butterknife.ButterKnife;
import butterknife.InjectView;
import butterknife.OnClick;
import hillfly.wifichat.R;

public class AcceptFragment extends BaseFragment {
    @Inject
    StateProvider stateProvider;

    @InjectView(R.id.avatarImageView)
    ImageView avatarImageView;

    @InjectView(R.id.button_accept)
    Button acceptButton;

    private RoomConnectionParameters roomConnectionParameters;
    private MediaPlayer mediaPlayer;

	public View onCreateView(LayoutInflater inflater, ViewGroup container,
	        Bundle savedInstanceState) {
		View view = inflater.inflate(R.layout.fragment_accept, container, false);
		ButterKnife.inject(this, view);
        RTCApplication.getComponent().inject(this);

		return view;
	}

    @Override
    public void onStart() {
        super.onStart();

        roomConnectionParameters = ((CallActivity)getActivity()).getParameters();
        if (null == roomConnectionParameters) {
            XLog.e("Invalid room parameter");
            getActivity().getSupportFragmentManager().popBackStack();
            return;
        }

        if (roomConnectionParameters.initiator && !roomConnectionParameters.loopback)
            acceptButton.setVisibility(View.GONE);

        if (!roomConnectionParameters.initiator) {
            Uri notification = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE);
            mediaPlayer = MediaPlayer.create(getActivity(), notification);
            mediaPlayer.start();
        }

        getView().setFocusableInTouchMode(true);
        getView().requestFocus();

        getView().setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if (event.getAction() == KeyEvent.ACTION_DOWN) {
                    if (keyCode == KeyEvent.KEYCODE_BACK) {
                        onRejectClick();
                        return true;
                    }
                }
                return false;
            }
        });

        // check state
        if (!stateProvider.getState().equals(StateProvider.State.STATE_SIGNIN)) {
            XLog.e("Invalid state: " + stateProvider.getState());
            getActivity().getSupportFragmentManager().popBackStack();
            return;
        }

        // signal channel
        stateProvider.call(roomConnectionParameters);

        if (roomConnectionParameters.loopback)
            onAcceptClick();
    }

    @Override
    public void onStop() {
        super.onStop();
        if (null != mediaPlayer) {
            mediaPlayer.stop();
            mediaPlayer = null;
        }
    }

	@OnClick(R.id.button_accept)
    @SuppressWarnings("unused")
    public void onAcceptClick() {
        stateProvider.accept();
        CallFragment callFragment = new CallFragment();
        getActivity().getSupportFragmentManager().beginTransaction().replace(
                R.id.call_frame, callFragment).commit();
    }

    @OnClick(R.id.button_reject)
    @SuppressWarnings("unused")
    public void onRejectClick() {
        stateProvider.hangup();
        getActivity().finish();
    }

    @SuppressWarnings("unused")
    public void onEventMainThread(AcceptSignal acceptSignal) {
        XLog.d("Receive AcceptSignal from " + acceptSignal.getCallFrom());
        if (!roomConnectionParameters.loopback) {
            CallFragment callFragment = new CallFragment();
            getActivity().getSupportFragmentManager().beginTransaction().replace(
                    R.id.call_frame, callFragment).commit();
        }
    }

    @SuppressWarnings("unused")
    public void onEventMainThread(DisconnectSignal disconnectSignal) {
        XLog.d("Receive DisconnectSignal from " + disconnectSignal.getCallFrom());

        onRejectClick();
    }
}
