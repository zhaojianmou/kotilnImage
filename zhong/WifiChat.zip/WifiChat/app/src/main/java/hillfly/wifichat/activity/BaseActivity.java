package hillfly.wifichat.activity;

import android.support.v4.app.FragmentActivity;
import android.os.Bundle;

import org.appspot.apprtc.XLog;

import butterknife.ButterKnife;
import de.greenrobot.event.EventBus;

/**
 * Created by cxm on 7/31/16.
 */
public class BaseActivity extends FragmentActivity {
    @Override
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        XLog.i("onCreate: " + this);
    }

    @Override
    public void setContentView(int id) {
        super.setContentView(id);
        ButterKnife.inject(this);
    }

    @Override
    public void onStart() {
        XLog.i("onStart: " + this);
        super.onStart();
        EventBus.getDefault().register(this);
    }

    @Override
    public void onStop() {
        super.onStop();
        EventBus.getDefault().unregister(this);
        XLog.i("onStop: " + this);
    }

    @Override
    public void onResume() {
        XLog.i("onResume: " + this);
        super.onResume();
    }

    @Override
    public void onPause() {
        super.onPause();
        XLog.i("onPause: " + this);
    }

    public static class EventDummy {

    }

    @SuppressWarnings("unused")
    public void onEvent(EventDummy eventDummy) {

    }
}
