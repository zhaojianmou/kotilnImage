package hillfly.wifichat.activity;

import butterknife.ButterKnife;
import butterknife.OnClick;
import hillfly.wifichat.R;
import hillfly.wifichat.common.BaseActivity;
import hillfly.wifichat.util.PackageUtils;

import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

public class AboutActivity extends BaseActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about);
        ButterKnife.inject(this);
        initEvents();
    }

    @Override
    protected void initViews() {
    }

    @Override
    protected void initEvents() {
        TextView titleTv = (TextView) findViewById(R.id.titleTv);
        titleTv.setText(R.string.title_about);

        TextView version = (TextView) findViewById(R.id.version);
        version.setText("版本号:  " + PackageUtils.getVersion(this));

    }

    // actionBar的监听
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        finish();
        return true;
    }


    @OnClick({R.id.left})
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.left:
                finish();
                break;
        }
    }
}
