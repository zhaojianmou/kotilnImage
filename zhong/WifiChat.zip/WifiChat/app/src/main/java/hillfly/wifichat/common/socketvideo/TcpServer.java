package hillfly.wifichat.common.socketvideo;


import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Handler;
import android.os.Message;
import android.util.Log;

import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.IOException;
import java.lang.reflect.Array;
import java.net.ServerSocket;
import java.net.Socket;

import io.reactivex.Observable;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.functions.Consumer;
import io.reactivex.functions.Function;
import io.reactivex.schedulers.Schedulers;

public class TcpServer {
    private static TcpServer tcpServer;

    private ServerSocket serverSocket;
    private Handler handler;


    private TcpServer() {

    }

    public static TcpServer getInstance() {
        if (tcpServer == null) {
            tcpServer = new TcpServer();
        }
        return tcpServer;
    }


    public TcpServer create() throws IOException {
        if (serverSocket == null) {
            serverSocket = new ServerSocket(VideoConsts.PORT_VIDEO_SERVER);
        }
        return this;
    }

    public void start() {
        try {
            while (true) {
                Socket socket = serverSocket.accept();
//                Log.e("22222", "server socket");
                Observable.just(socket).map(new Function<Socket, Object>() {
                    @Override
                    public Object apply(Socket s) throws Exception {
                        if (s.isConnected()) {
//                            BufferedInputStream in = new BufferedInputStream(s.getInputStream());
//                            ByteArrayOutputStream out = new ByteArrayOutputStream();
//                            byte[] data = new byte[1024];
//                            int falg = 0;
//                            while ((falg = in.read(data)) != -1) {
//                                out.write(data);
//                            }
//                            out.flush();

                            if (handler != null) {
                                Bitmap bitmap = BitmapFactory.decodeStream(s.getInputStream());

//                                Bitmap bitmap = BitmapFactory.decodeByteArray(out.toByteArray(), 0, out.toByteArray().length);
                                Message message = handler.obtainMessage();
                                message.obj = bitmap;
                                handler.sendMessage(message);
                            }
//                            out.close();
//                            in.close();
                            s.close();
                        }
                        return "";
                    }
                }).subscribeOn(Schedulers.io())
                        .observeOn(AndroidSchedulers.mainThread()).subscribe(new Consumer<Object>() {
                    @Override
                    public void accept(Object o) throws Exception {
                    }
                });
            }
        } catch (IOException e) {
            e.printStackTrace();
        }


    }

    public void setHandler(Handler handler) {
        this.handler = handler;

    }


}
