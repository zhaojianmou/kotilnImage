package hillfly.wifichat.activity;

import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import org.appspot.apprtc.AppRTCAudioManager;
import org.appspot.apprtc.AppRTCClient;
import org.appspot.apprtc.PeerConnectionClient;
import org.appspot.apprtc.RTCApplication;
import org.appspot.apprtc.StateProvider;
import org.appspot.apprtc.XLog;
import org.appspot.apprtc.data.CallSignal;
import org.appspot.apprtc.data.DisconnectSignal;
import org.appspot.apprtc.data.IceAddSignal;
import org.appspot.apprtc.data.IceRemoveSignal;
import org.appspot.apprtc.data.RoomConnectionParameters;
import org.appspot.apprtc.data.SdpSignal;
import org.webrtc.EglBase;
import org.webrtc.IceCandidate;
import org.webrtc.PeerConnection;
import org.webrtc.PeerConnectionFactory;
import org.webrtc.SessionDescription;
import org.webrtc.StatsReport;
import org.webrtc.SurfaceViewRenderer;

import java.text.SimpleDateFormat;
import java.util.LinkedList;

import javax.inject.Inject;

import butterknife.ButterKnife;
import butterknife.InjectView;
import butterknife.OnClick;
import hillfly.wifichat.R;

/**
 * Created by cxm on 8/3/16.
 */
public class CallFragment extends BaseFragment implements PeerConnectionClient.PeerConnectionEvents, Runnable {
    @Inject
    StateProvider stateProvider;

    @InjectView(R.id.text_view_buddy_name)
    TextView buddyName;

    @InjectView(R.id.local_video_view)
    SurfaceViewRenderer localRender;

    @InjectView(R.id.micButton)
    Button micButton;

    @InjectView(R.id.muteButton)
    Button muteButton;

    @InjectView(R.id.remote_video_view)
    SurfaceViewRenderer remoteRender;

    @InjectView(R.id.text_view_time)
    TextView timeTextView;

    private PeerConnectionClient.PeerConnectionParameters peerConnectionParameters;
    private RoomConnectionParameters roomConnectionParameters;
    private PeerConnectionClient peerConnectionClient = null;

    private boolean isMicEnable = true;
    private boolean isAudioEnable = true;

    private boolean isPingStart = false;
    private boolean isFinish = false;
    private long startTime = 0;

    private AppRTCAudioManager audioManager = null;
    private Handler handler = new Handler();

    // video render
    private EglBase rootEglBase;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_call_buddy, container, false);
        RTCApplication.getComponent().inject(this);
        ButterKnife.inject(this, view);
        return view;
    }

    @Override
    public void onStart() {
        super.onStart();

        // check state
        if (!stateProvider.getState().equals(StateProvider.State.STATE_CONNECTING)) {
            XLog.e("Invalid state: " + stateProvider.getState());
            getActivity().getSupportFragmentManager().popBackStack();
            return;
        }
        // check parameter
        roomConnectionParameters = stateProvider.getAppRtcClient().getParameters();
        if (null == roomConnectionParameters) {
            XLog.e("Invalid room parameter");
            getActivity().getSupportFragmentManager().popBackStack();
            return;
        }

        // Create video renderers.
        rootEglBase = EglBase.create();
        localRender.init(rootEglBase.getEglBaseContext(), null);
        remoteRender.init(rootEglBase.getEglBaseContext(), null);
        localRender.setZOrderMediaOverlay(true);

        peerConnectionParameters = PeerConnectionParameterHelper.initParams(
                getActivity(), roomConnectionParameters);

        peerConnectionClient = PeerConnectionClient.getInstance();
        if (roomConnectionParameters.loopback) {
            PeerConnectionFactory.Options options = new PeerConnectionFactory.Options();
            options.networkIgnoreMask = 0;
            peerConnectionClient.setPeerConnectionFactoryOptions(options);
        }
        peerConnectionClient.createPeerConnectionFactory(
                this.getActivity(), peerConnectionParameters, this);

        connectTo();

        audioManager = AppRTCAudioManager.create(this.getActivity(), new Runnable() {
            @Override
            public void run() {
            }
        });
        audioManager.init();
    }

    @Override
    public void onStop() {
        stateProvider.hangup();

        if (peerConnectionClient != null) {
            peerConnectionClient.close();
            peerConnectionClient = null;
        }
        if (localRender != null) {
            localRender.release();
            // localRender = null;
        }
        if (remoteRender != null) {
            remoteRender.release();
            // remoteRender = null;
        }
        if (null != rootEglBase) {
            rootEglBase.release();
            rootEglBase = null;
        }

        if (null != audioManager) {
            audioManager.close();
            audioManager = null;
        }

        super.onStop();
    }

    private void connectTo() {
        LinkedList<PeerConnection.IceServer> iceServers = new LinkedList<>();
        AppRTCClient.SignalingParameters signalingParameters = new AppRTCClient.SignalingParameters(
                iceServers, roomConnectionParameters.loopback,
                null, null, null,
                null, null);

        peerConnectionClient.createPeerConnection(rootEglBase.getEglBaseContext(),
                localRender, remoteRender, signalingParameters);
        if (roomConnectionParameters.initiator) {
            // Create offer. Offer SDP will be sent to answering client in
            // PeerConnectionEvents.onLocalDescription event.
            peerConnectionClient.createOffer();
        }
    }

    @OnClick(R.id.micButton)
    @SuppressWarnings("unused")
    public void onMicClick() {
        isMicEnable = !isMicEnable;
        if (isMicEnable) {
            audioManager.setAudioDevice(AppRTCAudioManager.AudioDevice.SPEAKER_PHONE);
            micButton.setBackgroundResource(R.drawable.vol);
        }
        else{
            audioManager.setAudioDevice(AppRTCAudioManager.AudioDevice.EARPIECE);
            micButton.setBackgroundResource(R.drawable.no_vol_down);
        }
    }

    @OnClick(R.id.muteButton)
    @SuppressWarnings("unused")
    public void onMuteClick() {
        isAudioEnable = !isAudioEnable;
        if (isAudioEnable){
            muteButton.setBackgroundResource(R.drawable.mic_down);
        }else{
            muteButton.setBackgroundResource(R.drawable.mute);
        }
        peerConnectionClient.setAudioEnabled(isAudioEnable);
    }

    @Override
    public void onLocalDescription(SessionDescription sdp) {
        XLog.d("onLocalDescription: " + sdp.description);
        stateProvider.getAppRtcClient().sendOfferSdp(sdp);
    }

    @Override
    public void onIceCandidate(IceCandidate candidate) {
        XLog.d("onIceCandidate: " + candidate);
        stateProvider.getAppRtcClient().sendLocalIceCandidate(candidate);
    }

    @Override
    public void onIceCandidatesRemoved(IceCandidate[] candidates) {
        XLog.d("onIceCandidateRemoved: " + candidates);
    }

    @Override
    public void onIceConnected() {
        XLog.d("onIceConnected");
    }

    @Override
    public void onIceDisconnected() {
        XLog.d("onIceDisconnected");
    }

    @Override
    public void onPeerConnectionClosed() {
        XLog.d("onPeerConnectionClosed");
    }

    @Override
    public void onPeerConnectionStatsReady(StatsReport[] reports) {
        XLog.d("onPeerConnectionStatsReady: " + reports);
    }

    @Override
    public void onPeerConnectionError(String description) {
        XLog.d("onPeerConnectionError: " + description);
    }

    @SuppressWarnings("unused")
    public void onEventMainThread(CallSignal signal) {
        // must be loopback
        XLog.d("Receive CallSignal from " + signal.getCallFrom());
        stateProvider.getAppRtcClient().getParameters().updateParameterFromCallSignal(signal);
    }

    @SuppressWarnings("unused")
    public void onEventMainThread(DisconnectSignal disconnectSignal) {
        XLog.d("Receive DisconnectSignal from " + disconnectSignal.getCallFrom());

        if (!isFinish)
            this.getActivity().finish();
        isFinish = true;
    }

    @SuppressWarnings("unused")
    public void onEventMainThread(SdpSignal sdpSignal) {
        peerConnectionClient.setRemoteDescription(sdpSignal.getData());

        if (!roomConnectionParameters.initiator && !roomConnectionParameters.loopback) {
            peerConnectionClient.createAnswer();
        }
    }

    @SuppressWarnings("unused")
    public void onEventMainThread(IceAddSignal signal) {
        peerConnectionClient.addRemoteIceCandidate(signal.getData());
    }

    @SuppressWarnings("unused")
    public void onEventMainThread(IceRemoveSignal signal) {
        peerConnectionClient.removeRemoteIceCandidates(signal.getIceCandidates());
    }

    @Override
    public void run() {
        handler.postDelayed(this, 1000);
       /* int sec = (int)(System.currentTimeMillis() - startTime) / 1000;
        timeTextView.setText("" + sec);*/
        //there need check server how to calcute the time ,just second?
        Long milSec = System.currentTimeMillis() - startTime;
        SimpleDateFormat formatter = new SimpleDateFormat("mm:ss");//初始化Formatter的转换格式。
        String time = formatter.format(milSec);
        timeTextView.setText("" + time);
    }
}
