package hillfly.wifichat.activity;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.Switch;
import android.widget.TextView;

import butterknife.ButterKnife;
import butterknife.InjectView;
import butterknife.OnClick;
import hillfly.wifichat.R;
import hillfly.wifichat.common.ActivitiesManager;
import hillfly.wifichat.common.BaseActivity;
import hillfly.wifichat.common.BaseApplication;
import hillfly.wifichat.common.BaseDialog;
import hillfly.wifichat.common.socket.udp.UDPMessageListener;
import hillfly.wifichat.common.sql.SqlDBOperate;
import hillfly.wifichat.common.view.SettingSwitchButton;
import hillfly.wifichat.util.FileUtils;
import hillfly.wifichat.util.PackageUtils;

public class SetActivity extends BaseActivity implements CompoundButton.OnCheckedChangeListener, DialogInterface.OnClickListener {

    @InjectView(R.id.btn_about_us)
    public Button mAboutUsButton;
    @InjectView(R.id.btn_delete_all_chattinginfo)
    public Button mDeleteAllChattingInfoButton;
    @InjectView(R.id.btn_exit_application)
    public Button mExitApplicationButton;

    @InjectView(R.id.btn_setting_my_information)
    public ImageView mSettingInfoButton;
    @InjectView(R.id.checkbox_sound)
    public Switch mSoundSwitchButton;
    @InjectView(R.id.checkbox_vibration)
    public Switch mVibrateSwitchButton;
    @InjectView(R.id.setting_my_info_layout)
    public RelativeLayout mSettingInfoLayoutButton;


    private BaseDialog mDeleteCacheDialog; // 提示窗口
    private BaseDialog mExitDialog;
    private SqlDBOperate mSqlDBOperate;

    private int mDialogFlag;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_set);
        ButterKnife.inject(this);
        initViews();
    }


    @Override
    protected void initEvents() {
    }

    @Override
    protected void initViews() {

        TextView titleTv = (TextView) findViewById(R.id.titleTv);
        titleTv.setText(R.string.title_set);

        mSoundSwitchButton.setOnCheckedChangeListener(this);
        mVibrateSwitchButton.setOnCheckedChangeListener(this);

        mDeleteCacheDialog = BaseDialog.getDialog(this, R.string.dialog_tips,
                getString(R.string.setting_dialog_chatlog_delete_confirm),
                getString(R.string.setting_dialog_chatlog_delete_ok), this,
                getString(R.string.setting_dialog_chatlog_delete_cancel), this);

        mExitDialog = BaseDialog.getDialog(this, R.string.dialog_tips,
                getString(R.string.setting_dialog_logout_confirm),
                getString(R.string.setting_dialog_logout_ok), this,
                getString(R.string.setting_dialog_logout_cancel), this);

        mSoundSwitchButton.setChecked(BaseApplication.getSoundFlag());
        mVibrateSwitchButton.setChecked(BaseApplication.getVibrateFlag());

        mUDPListener = UDPMessageListener.getInstance(this);
    }


    @OnClick({R.id.left, R.id.setting_my_info_layout, R.id.btn_delete_all_chattinginfo,
            R.id.btn_about_us, R.id.btn_exit_application})
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.left:
                finish();
                break;
            case R.id.setting_my_info_layout:
                startActivity(SettingInfoActivity.class);
                break;

            case R.id.btn_delete_all_chattinginfo:
                mDialogFlag = 1;
                mDeleteCacheDialog.show();
                break;

            case R.id.btn_about_us:
                startActivity(AboutActivity.class);
                break;

            case R.id.btn_exit_application:
                mDialogFlag = 2;
                mExitDialog.show();
                break;
        }
    }


    @Override
    public void onClick(DialogInterface dialog, int which) {
        switch (mDialogFlag) {
            case 1:
                if (which == 0) {
                    setAsyncTask(1);
                } else if (which == 1) {
                    mDeleteCacheDialog.dismiss();
                }
                break;
            case 2:
                if (which == 0) {
                    setAsyncTask(2);
                } else if (which == 1) {
                    mExitDialog.dismiss();
                }
                break;
        }

    }

    @Override
    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
        switch (buttonView.getId()) {
            case R.id.checkbox_sound:
                buttonView.setChecked(isChecked);
                BaseApplication.setSoundFlag(!isChecked);
                break;

            case R.id.checkbox_vibration:
                buttonView.setChecked(isChecked);
                BaseApplication.setVibrateFlag(isChecked);
                break;

            default:
                break;
        }

    }

    @SuppressLint("StaticFieldLeak")
    private void setAsyncTask(final int flag) {
        putAsyncTask(new AsyncTask<Void, Void, Boolean>() {
            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                switch (flag) {
                    case 1:
                        mDeleteCacheDialog.dismiss();
                        showLoadingDialog(getString(R.string.setting_dialog_chatlog_deleting));
                        break;
                    case 2:
                        mExitDialog.dismiss();
                        showLoadingDialog(getString(R.string.setting_dialog_logout_confirm));
                        break;
                    default:
                        break;
                }

            }

            @Override
            protected Boolean doInBackground(Void... params) {
                try {
                    switch (flag) {
                        case 1:
                            mSqlDBOperate = new SqlDBOperate(SetActivity.this);
                            mSqlDBOperate.deteleAllChattingInfo();
                            mSqlDBOperate.close();
                            mUDPListener.clearMsgCache();
                            mUDPListener.clearUnReadMessages();
                            FileUtils.delAllFile(BaseApplication.SAVE_PATH);
                            break;

                        case 2:
                            break;

                        default:
                            break;
                    }
                    return true;
                } catch (Exception e) {
                    e.printStackTrace();
                }
                return false;
            }

            @Override
            protected void onPostExecute(Boolean result) {
                super.onPostExecute(result);
                dismissLoadingDialog();
                if (result) {
                    dismissLoadingDialog();
                    switch (flag) {
                        case 1:
//                            ((MainTabActivity) SetActivity.this).handler.sendEmptyMessage(0);
                            showShortToast(R.string.setting_dialog_toast_delect_success);
                            break;

                        case 2:
                            ActivitiesManager.finishAllActivities(SetActivity.this
                                    .getApplicationContext());
                            break;

                        default:
                            break;
                    }

                } else {
                    showShortToast(R.string.setting_dialog_toast_delect_failue);
                }
            }
        });
    }


}
