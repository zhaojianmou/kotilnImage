package hillfly.wifichat.common.socketvideo;

public class VideoConsts {

    public static final int PORT_VIDEO_SERVER = 15555;
    public static final int PORT_VIDEO_CLIENT = 15556;
    public static final int PORT_AUDIO_SERVER = 15511;
    public static final int PORT_AUDIO_CLIENT = 15512;

    public static final String VIDEO_WIDTH = "width";
    public static final String VIDEO_HEIGHT = "height";


}
