package hillfly.wifichat.common.socketvideo;


import android.graphics.Bitmap;
import android.text.TextUtils;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.nio.ByteBuffer;


public class VideoServer {

    private static VideoServer videoServer;

    private DatagramSocket socket;
    private DatagramPacket sendPacket;
    private String ip;

    private VideoServer() {
    }

    public static VideoServer getInstance() {
        if (videoServer == null) {
            videoServer = new VideoServer();
        }
        return videoServer;
    }


    public VideoServer create() throws SocketException {
        if (socket == null) {
            socket = new DatagramSocket(VideoConsts.PORT_VIDEO_SERVER);
        }
        return this;
    }

    public void send(Bitmap bitmap) throws IOException {
        if (TextUtils.isEmpty(ip)) {
            return;
        }
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, baos);


        byte[] buf = baos.toByteArray();
        int unit = 1024 * 3;
        int bitLong = buf.length;
        int falg = 0;

        byte[] start = ("start").getBytes();
        sendPacket = new DatagramPacket(start, start.length, InetAddress.getByName(ip), VideoConsts.PORT_VIDEO_CLIENT);
        socket.send(sendPacket);

        while (falg < bitLong) {
            if ((falg + unit) < bitLong) {
                sendPacket = new DatagramPacket(buf, falg, unit, InetAddress.getByName(ip), VideoConsts.PORT_VIDEO_CLIENT);
            } else {
                sendPacket = new DatagramPacket(buf, falg, bitLong - falg, InetAddress.getByName(ip), VideoConsts.PORT_VIDEO_CLIENT);
            }
            socket.send(sendPacket);
            falg = falg + unit;
        }


        byte[] end = ("endee").getBytes();
        sendPacket = new DatagramPacket(end, end.length, InetAddress.getByName(ip), VideoConsts.PORT_VIDEO_CLIENT);
        socket.send(sendPacket);

        bitmap.recycle();
        bitmap = null;


    }

    public void setIp(String ip) {
        this.ip = ip;
    }


}
