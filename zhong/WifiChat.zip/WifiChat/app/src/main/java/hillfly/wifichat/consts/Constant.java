package hillfly.wifichat.consts;


public class Constant {

    public static final int TCP_SERVER_RECEIVE_PORT = 4447; // 主机接收端口
    public static int READ_BUFFER_SIZE = 1024*4;// 文件流缓冲大小
}
