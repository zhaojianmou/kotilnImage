//package hillfly.wifichat.activity;
//
//import android.app.Activity;
//import android.content.SharedPreferences;
//import android.hardware.Camera;
//import android.os.Bundle;
//import android.preference.PreferenceManager;
//import android.view.SurfaceHolder;
//
//import net.majorkernelpanic.streaming.Session;
//import net.majorkernelpanic.streaming.SessionBuilder;
//import net.majorkernelpanic.streaming.audio.AudioQuality;
//import net.majorkernelpanic.streaming.gl.SurfaceView;
//import net.majorkernelpanic.streaming.rtsp.RtspServer;
//import net.majorkernelpanic.streaming.video.VideoQuality;
//
//import java.io.IOException;
//
//import hillfly.wifichat.R;
//import hillfly.wifichat.common.view.VideoView;
//
//
//public class VideoViewActivity extends Activity implements Session.Callback, SurfaceHolder.Callback, Camera.PreviewCallback {
//    private VideoView videoView;
//    private SurfaceView surfaceView;
//    private SurfaceHolder surfaceHolder;
//    private Camera camera;
//
//    private Session mSession;
//
//    private int previewWidth, previewHeight;
//
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_videoview);
//        initView();
//    }
//
//    private void initView() {
//        videoView = (VideoView) findViewById(R.id.videoView);
//        surfaceView = (SurfaceView) findViewById(R.id.surfaceView);
//        surfaceHolder = surfaceView.getHolder();
//
//        SharedPreferences.Editor editor = PreferenceManager.getDefaultSharedPreferences(this).edit();
//        editor.putString(RtspServer.KEY_PORT, String.valueOf(18686));
//        editor.commit();
//
//        mSession = SessionBuilder.getInstance()
//                .setCallback(this)
//                .setSurfaceView(surfaceView)
//                .setPreviewOrientation(90)
//                .setContext(getApplicationContext())
//                .setAudioEncoder(SessionBuilder.AUDIO_NONE)
//                .setAudioQuality(new AudioQuality(16000, 32000))
//                .setVideoEncoder(SessionBuilder.VIDEO_H264)
//                .setVideoQuality(new VideoQuality(320, 240, 20, 500000))
//                .build();
//
//        surfaceView.getHolder().addCallback(this);
//    }
//
//    @Override
//    public void onResume() {
//        super.onResume();
//        if (mSession.isStreaming()) {
////            mButton1.setText(R.string.stop);
//        } else {
////            mButton1.setText(R.string.start);
//        }
//    }
//
//    @Override
//    public void onDestroy() {
//        super.onDestroy();
//        mSession.release();
//    }
//
//    @Override
//    public void onPreviewFrame(byte[] data, Camera camera) {
//
//    }
//
//    @Override
//    public void surfaceCreated(SurfaceHolder holder) {
//        mSession.startPreview();
//    }
//
//    @Override
//    public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {
//        mSession.stop();
//    }
//
//    @Override
//    public void surfaceDestroyed(SurfaceHolder holder) {
//
//    }
//
//    @Override
//    public void onBitrateUpdate(long bitrate) {
//
//    }
//
//    @Override
//    public void onSessionError(int reason, int streamType, Exception e) {
//
//    }
//
//    @Override
//    public void onPreviewStarted() {
//
//    }
//
//    @Override
//    public void onSessionConfigured() {
//        mSession.start();
//
//    }
//
//    @Override
//    public void onSessionStarted() {
//
//    }
//
//    @Override
//    public void onSessionStopped() {
//
//    }
//}
