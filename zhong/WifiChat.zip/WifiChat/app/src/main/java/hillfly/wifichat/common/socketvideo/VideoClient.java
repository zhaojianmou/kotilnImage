package hillfly.wifichat.common.socketvideo;


import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Handler;
import android.os.Message;
import android.util.Log;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;

public class VideoClient {
    private static VideoClient videoClient;

    private DatagramSocket socket;
    private DatagramPacket receivePacket;
    private boolean isBitmapStart = false;
    private ByteArrayOutputStream out;

    private int width, height;


    private VideoClient() {
    }

    public static VideoClient getInstance() {
        if (videoClient == null) {
            videoClient = new VideoClient();
        }
        return videoClient;
    }

    public VideoClient create() {
        try {
            if (socket == null) {
                socket = new DatagramSocket(VideoConsts.PORT_VIDEO_CLIENT);
            }
            byte[] buf = new byte[1024 * 10];
            receivePacket = new DatagramPacket(buf, buf.length);
            out = new ByteArrayOutputStream();
        } catch (SocketException e) {
            e.printStackTrace();
        }
        return this;
    }


    public void receive(Handler handler) {
        Bitmap bitmap = null;
        try {
            while (true) {

                socket.receive(receivePacket);
                Log.e("111", "receive receivePacket:" + "-------" + receivePacket.getSocketAddress());
//                Log.e("111", "receive receivePacket:" + new String(receivePacket.getData(), 0, receivePacket.getLength()) + "-------" + receivePacket.getSocketAddress());
                byte[] data = null;
                if (receivePacket.getLength() == 5) {
                    String msg = new String(receivePacket.getData(), 0, receivePacket.getLength());
                    if ("start".equals(msg)) {
                        Log.e("111", "receive receivePacket:" + "-------" + msg);
                        isBitmapStart = true;
                        out.reset();
                        continue;
                    }
                    if ("endee".equals(msg)) {
                        Log.e("111", "receive receivePacket:" + "-------" + msg);
                        isBitmapStart = false;
                        data = out.toByteArray();
                    }
                }

                if (isBitmapStart) {
                    out.write(receivePacket.getData());
                } else if (data != null) {
                    bitmap = BitmapFactory.decodeByteArray(data, 0, data.length);
                    Message message = handler.obtainMessage();
                    message.obj = bitmap;
                    handler.sendMessage(message);
                }

            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {

        }
    }


}
