package hillfly.wifichat.common.view;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.util.AttributeSet;
import android.view.View;

/**
 * Created by kele on 2017/11/15.
 */

public class VideoView extends View {

    Bitmap bitmap;
    //    public static int height = WinChatApplication.height - 200 - 50;
//    public static int width = (int) (WinChatApplication.height * 0.75);
    Matrix matrix = new Matrix();

    private void init() {
//    	matrix.setRotate(-90);
//        matrix.postScale(3f, 2.5f);
    }

    public VideoView(Context context) {
        super(context);
    }

    public VideoView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public VideoView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }


    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (bitmap != null) {
            canvas.drawBitmap(bitmap, 0, 0, null);
//			canvas.drawBitmap(bitmap, matrix, null);
            bitmap.recycle();
            bitmap = null;
        }
    }

    public Bitmap getBitmap() {
        return bitmap;
    }

    public void setBitmap(Bitmap bitmap) {
        this.bitmap = bitmap;
        invalidate();
    }
}
