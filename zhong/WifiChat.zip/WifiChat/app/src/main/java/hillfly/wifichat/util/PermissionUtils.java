package hillfly.wifichat.util;


import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;
import android.support.v4.content.ContextCompat;

public class PermissionUtils {

    public static boolean isPermissionVersion() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            return true;
        }
        return false;
    }

    public static boolean checkPermission(Context context, String permission) {

        if (isPermissionVersion()) {
            int i = ContextCompat.checkSelfPermission(context, permission);
            if (i == PackageManager.PERMISSION_GRANTED) {
                return true;
            }

        }
        return false;
    }

    public static boolean checkPermissions(Context context, String... permission) {

        if (isPermissionVersion()) {
            boolean per = true;
            for (String p : permission) {
                int i = ContextCompat.checkSelfPermission(context, p);
                if (i == PackageManager.PERMISSION_GRANTED) {
                    per = per && true;
                } else {
                    per = per && false;
                }
            }
            return per;


        }
        return false;
    }


}
