package hillfly.wifichat.activity;

import hillfly.wifichat.R;
import hillfly.wifichat.common.BaseActivity;

import android.os.Bundle;
import android.support.v4.media.session.PlaybackStateCompat;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.widget.Button;
import android.widget.RelativeLayout;
import android.widget.TextView;

import org.appspot.apprtc.ChannelsProvider;
import org.appspot.apprtc.RTCApplication;
import org.appspot.apprtc.RTCComponent;
import org.appspot.apprtc.StateProvider;
import org.appspot.apprtc.data.RoomConnectionParameters;

import javax.inject.Inject;

public class WelcomeActivity extends BaseActivity implements OnClickListener {

    private Button mBtnLogin;
    private RelativeLayout welcomeBg;

    @Inject
    StateProvider stateProvider;

    @Inject
    ChannelsProvider channelsProvider;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome);
        initViews();
        initEvents();

        RTCApplication.getComponent().inject(this);

        stateProvider.login();
        channelsProvider.init();
    }

    @Override
    protected void initViews() {

        mBtnLogin = (Button) findViewById(R.id.welcome_btn_login);
        welcomeBg = (RelativeLayout) findViewById(R.id.welcomeBg);
        AlphaAnimation alphaAnimation = new AlphaAnimation(0.1f, 1.0f);
        alphaAnimation.setInterpolator(new AccelerateInterpolator());
        alphaAnimation.setDuration(1500);
        alphaAnimation.setFillAfter(true);
        welcomeBg.startAnimation(alphaAnimation);


        alphaAnimation.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {

            }

            @Override
            public void onAnimationEnd(Animation animation) {
                startActivity(LoginActivity.class);
                WelcomeActivity.this.finish();

            }

            @Override
            public void onAnimationRepeat(Animation animation) {

            }
        });
    }

    @Override
    protected void initEvents() {
        mBtnLogin.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {

            case R.id.welcome_btn_login:
                startActivity(LoginActivity.class);
//            RoomConnectionParameters roomConnectionParameters =
//                    new RoomConnectionParameters(
//                            null, null, true, true);
//
//            CallActivity.startCall(this, roomConnectionParameters);
                break;

        }
    }

}
