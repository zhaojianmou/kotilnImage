package hillfly.wifichat.activity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;

import com.google.gson.Gson;

import org.appspot.apprtc.RTCApplication;
import org.appspot.apprtc.XLog;
import org.appspot.apprtc.data.RoomConnectionParameters;
import hillfly.wifichat.R;

/**
 * Created by cxm on 2/28/17.
 */
public class CallActivity extends BaseActivity {
    public static final String EXTRA_KEY_CALL_SIGNAL = "EXTRA_KEY_CALL_SIGNAL";
    public static final String EXTRA_KEY_ROOM_CONNECTION_PARAMETER =
            "EXTRA_KEY_ROOM_CONNECTION_PARAMETER";

    private RoomConnectionParameters parameters;

    public RoomConnectionParameters getParameters() { return parameters; }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Intent intent = getIntent();
        if (null == intent) {
            XLog.e("Cannot get parameter");
            finish();
            return;
        }
        String parameter = intent.getStringExtra(EXTRA_KEY_ROOM_CONNECTION_PARAMETER);
        Gson gson = new Gson();
        parameters = gson.fromJson(parameter, RoomConnectionParameters.class);
        if (null == parameter) {
            XLog.e("Cannot get parameter");
            finish();
            return;
        }

        RTCApplication.getComponent().inject(this);

        getWindow().addFlags(
                WindowManager.LayoutParams.FLAG_FULLSCREEN
                        | WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
                        | WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD
                        | WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED
                        | WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON);
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);

        setContentView(R.layout.activity_call2);

        AcceptFragment acceptFragment = new AcceptFragment();
        getSupportFragmentManager().beginTransaction().replace(
                R.id.call_frame, acceptFragment).commit();
    }

    public static void startCall(Context context, RoomConnectionParameters parameters) {
        Intent intent = new Intent(context, CallActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        Gson gson = new Gson();
        intent.putExtra(CallActivity.EXTRA_KEY_ROOM_CONNECTION_PARAMETER,
                gson.toJson(parameters));
        context.startActivity(intent);
    }
}
