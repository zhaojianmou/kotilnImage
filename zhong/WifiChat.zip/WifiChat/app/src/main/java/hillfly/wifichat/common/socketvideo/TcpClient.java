package hillfly.wifichat.common.socketvideo;


import android.graphics.Bitmap;
import android.util.Log;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.Socket;

public class TcpClient {

    private static TcpClient tcpClient;

    private String ip;

    private TcpClient() {
    }

    public static TcpClient getInstance() {
        if (tcpClient == null) {
            tcpClient = new TcpClient();
        }
        return tcpClient;
    }


    public void sendData(Bitmap bitmap) {
//        Log.e("11111", "send ip:" + ip);
        try {
            Socket socket = new Socket(ip, VideoConsts.PORT_VIDEO_SERVER);
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            bitmap.compress(Bitmap.CompressFormat.PNG, 80, baos);

            OutputStream out = socket.getOutputStream();
            out.write(baos.toByteArray());
            out.flush();
            out.close();
            socket.close();
            bitmap.recycle();
            bitmap = null;

        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    public void sendMessage() {
       Socket socket=new Socket();

    }


    public void setIp(String ip) {
        this.ip = ip;
    }

}
